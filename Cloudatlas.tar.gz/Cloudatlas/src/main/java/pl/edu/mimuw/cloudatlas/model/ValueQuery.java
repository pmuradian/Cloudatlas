package pl.edu.mimuw.cloudatlas.model;

public class ValueQuery extends ValueString {

    public ValueQuery(String query) {
        super(query);
    }
}
